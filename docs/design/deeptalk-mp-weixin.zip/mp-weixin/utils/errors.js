"use strict";const e=require("../common/vendor.js").reactive({message:"",detail:""});exports.errorState=e;
