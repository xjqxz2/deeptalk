"use strict";const e=require("../common/vendor.js").reactive({message:"",detail:""});exports.clearError=function(){e.message="",e.detail=""},exports.errorState=e;
